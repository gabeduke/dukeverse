from django.apps import AppConfig


class ToolshedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'toolshed'
